#! /bin/bash
kill $(ps aux | grep 'lemp' | grep -v grep | grep -v 'start.sh' | awk '{print $2}') 2>/dev/null
sleep 1
kill $(ps aux | grep 'lemp' | grep -v grep | grep -v 'start.sh' | awk '{print $2}') 2>/dev/null
sleep 1
kill $(ps aux | grep 'lemp' | grep -v grep | grep -v 'start.sh' | awk '{print $2}') 2>/dev/null
sleep 4


chown -R lemp:lemp /home/lemp
sleep 4
/home/lemp/nginx/sbin/nginx
/home/lemp/proftpd/sbin/proftpd

start-stop-daemon --start --quiet --pidfile /home/lemp/php/php1.pid --exec /home/lemp/php/sbin/php-fpm -- --daemonize --fpm-config /home/lemp/php/etc/php1.conf
start-stop-daemon --start --quiet --pidfile /home/lemp/php/php2.pid --exec /home/lemp/php/sbin/php-fpm -- --daemonize --fpm-config /home/lemp/php/etc/php2.conf
start-stop-daemon --start --quiet --pidfile /home/lemp/php/php3.pid --exec /home/lemp/php/sbin/php-fpm -- --daemonize --fpm-config /home/lemp/php/etc/php3.conf
sudo chmod -R 777 /home/lemp/www
